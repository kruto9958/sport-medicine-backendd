require('dotenv').config();

const express = require('express');
const cors = require('cors');

require('./db');
require('./data/seed');

const authRoutes = require('./routes/auth');
const taskRoutes = require('./routes/tasks');
const solutionRoutes = require('./routes/solutions');
const leaderboardRoutes = require('./routes/leaderboard');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/solutions', solutionRoutes);
app.use('/api/leaderboard', leaderboardRoutes);

app.get('/', (req, res) => {
  res.json({
    message: 'Спортивное врачевание - API работает',
    endpoints: {
      'POST /api/auth/register': 'Регистрация',
      'POST /api/auth/login': 'Вход',
      'GET  /api/auth/me': 'Мой профиль (нужен токен)',
      'GET  /api/tasks': 'Список задач (нужен токен)',
      'GET  /api/tasks/:id': 'Задача по ID (нужен токен)',
      'POST /api/solutions/:taskId/solve': 'Отправить решение (нужен токен)',
      'GET  /api/solutions/my': 'Мои решения (нужен токен)',
      'GET  /api/leaderboard': 'Таблица лидеров'
    }
  });
});

app.listen(PORT, () => {
  console.log('Сервер запущен: http://localhost:' + PORT);
});