const express = require('express');
const db = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

function checkAnswer(userAnswer, correctAnswer) {
  const normalize = (str) => str.toLowerCase().replace(/ё/g, 'е');

  const normUser = normalize(userAnswer);
  const normCorrect = normalize(correctAnswer);

  const correctWords = normCorrect.split(/[\s,.\-\/]+/).filter(w => w.length > 3);

  if (correctWords.length === 0) return false;

  let matchCount = 0;

  for (const word of correctWords) {
    if (normUser.includes(word)) {
      const escaped = word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const negRegex = new RegExp(
        '(?:не|нет|без)\\s{0,10}' + escaped + '|' + escaped + '\\s{0,5}(?:не|нет|без)'
      );
      if (!negRegex.test(normUser)) {
        matchCount++;
      }
    }
  }

  return matchCount >= Math.ceil(correctWords.length * 0.6);
}

const submitSolution = db.transaction((userId, taskId, answer, isCorrect, points) => {
  db.prepare('INSERT INTO solutions (user_id, task_id, answer, is_correct) VALUES (?, ?, ?, ?)')
    .run(userId, taskId, answer, isCorrect ? 1 : 0);

  if (isCorrect) {
    db.prepare('UPDATE users SET score = score + ?, solved_count = solved_count + 1 WHERE id = ?')
      .run(points, userId);
  }
});

router.post('/:taskId/solve', authenticate, (req, res) => {
  const { taskId } = req.params;
  const { answer } = req.body;

  if (!answer) {
    return res.status(400).json({ error: 'Ответ не может быть пустым' });
  }

  if (typeof answer !== 'string') {
    return res.status(400).json({ error: 'Ответ должен быть строкой' });
  }

  const task = db.prepare('SELECT * FROM tasks WHERE id = ?').get(taskId);
  if (!task) {
    return res.status(404).json({ error: 'Задача не найдена' });
  }

  const alreadySolved = db.prepare(
    'SELECT id FROM solutions WHERE user_id = ? AND task_id = ? AND is_correct = 1'
  ).get(req.userId, taskId);

  if (alreadySolved) {
    return res.status(400).json({ error: 'Вы уже правильно решили эту задачу' });
  }

  const isCorrect = checkAnswer(answer, task.correct_answer);

  submitSolution(req.userId, taskId, answer, isCorrect, task.points);

  const user = db.prepare('SELECT score, solved_count FROM users WHERE id = ?').get(req.userId);

  res.json({
    is_correct: isCorrect,
    message: isCorrect
      ? 'Правильно! +' + task.points + ' очков'
      : 'Неверно. Попробуйте ещё раз.',
    correct_answer: isCorrect ? task.correct_answer : undefined,
    score: user.score,
    solved_count: user.solved_count
  });
});

router.get('/my', authenticate, (req, res) => {
  const solutions = db.prepare(`
    SELECT s.id, s.task_id, t.title, s.is_correct, s.submitted_at
    FROM solutions s
    JOIN tasks t ON s.task_id = t.id
    WHERE s.user_id = ?
    ORDER BY s.submitted_at DESC
  `).all(req.userId);

  res.json(solutions);
});

module.exports = router;