const express = require('express');
const db = require('../db');
const { authenticate } = require('../middleware/auth');

const router = express.Router();

router.get('/', authenticate, (req, res) => {
  const { category, difficulty } = req.query;

  let sql = 'SELECT id, title, description, category, difficulty, points, created_at FROM tasks WHERE 1=1';
  const params = [];

  if (category) {
    sql += ' AND category = ?';
    params.push(category);
  }
  if (difficulty) {
    sql += ' AND difficulty = ?';
    params.push(difficulty);
  }

  sql += ' ORDER BY points ASC';

  const tasks = db.prepare(sql).all(...params);

  const solved = db.prepare('SELECT task_id FROM solutions WHERE user_id = ? AND is_correct = 1').all(req.userId);
  const solvedIds = new Set(solved.map(s => s.task_id));

  const result = tasks.map(t => ({
    ...t,
    solved: solvedIds.has(t.id)
  }));

  res.json(result);
});

router.get('/:id', authenticate, (req, res) => {
  const task = db.prepare('SELECT id, title, description, category, difficulty, points FROM tasks WHERE id = ?').get(req.params.id);

  if (!task) {
    return res.status(404).json({ error: 'Задача не найдена' });
  }

  res.json(task);
});

module.exports = router;