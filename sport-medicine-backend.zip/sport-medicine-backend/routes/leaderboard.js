const express = require('express');
const db = require('../db');

const router = express.Router();

router.get('/', (req, res) => {
  let limit = parseInt(req.query.limit) || 20;

  if (limit > 100) {
    limit = 100;
  }
  if (limit < 1) {
    limit = 1;
  }

  const leaders = db.prepare(`
    SELECT id, username, score, solved_count, created_at
    FROM users
    ORDER BY score DESC, solved_count DESC
    LIMIT ?
  `).all(limit);

  res.json(leaders);
});

module.exports = router;